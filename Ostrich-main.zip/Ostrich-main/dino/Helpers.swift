import SpriteKit
import UIKit

class Settings {

    static var soundOn: Bool {
        get { return UserDefaults.standard.object(forKey: "soundOn") as? Bool ?? true }
        set { UserDefaults.standard.set(newValue, forKey: "soundOn") }
    }

    static var musicOn: Bool {
        get { return UserDefaults.standard.object(forKey: "musicOn") as? Bool ?? true }
        set { UserDefaults.standard.set(newValue, forKey: "musicOn") }
    }

    static var vibrationOn: Bool {
        get { return UserDefaults.standard.object(forKey: "vibrationOn") as? Bool ?? true }
        set { UserDefaults.standard.set(newValue, forKey: "vibrationOn") }
    }
}

func vibrate() {
    if Settings.vibrationOn {
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
    }
}

func gameVibrate(_ style: UIImpactFeedbackGenerator.FeedbackStyle) {
    guard Settings.vibrationOn else { return }

    let generator = UIImpactFeedbackGenerator(style: style)
    generator.impactOccurred()
}

func cutFrames(name: String, count: Int) -> [SKTexture] {
    let sheet = SKTexture(imageNamed: name)
    var frames: [SKTexture] = []
    for i in 0..<count {
        let rect = CGRect(x: CGFloat(i) / CGFloat(count), y: 0, width: 1 / CGFloat(count), height: 1)
        frames.append(SKTexture(rect: rect, in: sheet))
    }
    return frames
}

func autoFrames(name: String) -> [SKTexture] {
    let sheet = SKTexture(imageNamed: name)
    let s = sheet.size()
    if s.height == 0 {
        return [sheet]
    }
    let count = max(1, Int((s.width / s.height).rounded()))
    return cutFrames(name: name, count: count)
}

func makeButton(text: String, name: String, width: CGFloat) -> SKShapeNode {
    let button = SKShapeNode(rectOf: CGSize(width: width, height: 50), cornerRadius: 14)
    button.fillColor = SKColor(red: 0.15, green: 0.4, blue: 0.2, alpha: 0.95)
    button.strokeColor = .white
    button.lineWidth = 2
    button.name = name
    button.zPosition = 40

    let label = SKLabelNode(fontNamed: "AvenirNext-Bold")
    label.text = text
    label.fontSize = 20
    label.fontColor = .white
    label.verticalAlignmentMode = .center
    label.name = name
    button.addChild(label)

    return button
}

func setButtonText(_ button: SKShapeNode, _ text: String) {
    if let label = button.children.first as? SKLabelNode {
        label.text = text
    }
}

func makeTitle(_ text: String, fontSize: CGFloat, x: CGFloat, y: CGFloat) -> SKLabelNode {
    let label = SKLabelNode(fontNamed: "AvenirNext-Bold")
    label.text = text
    label.fontSize = fontSize
    label.fontColor = .white
    label.position = CGPoint(x: x, y: y)
    label.zPosition = 10
    return label
}

func tappedButton(_ scene: SKScene, _ touches: Set<UITouch>) -> String? {
    guard let touch = touches.first else {
        return nil
    }
    let point = touch.location(in: scene)
    for node in scene.nodes(at: point) {
        if let name = node.name, name.hasPrefix("btn") {
            return name
        }
    }
    return nil
}

func showScene(_ newScene: SKScene, from oldScene: SKScene) {
    newScene.scaleMode = oldScene.scaleMode
    oldScene.view?.presentScene(newScene, transition: SKTransition.fade(withDuration: 0.3))
}

extension SKScene {

    func playSound(_ name: String) {
        if Settings.soundOn {
            run(SKAction.playSoundFileNamed(name, waitForCompletion: false))
        }
    }

    func addMenuBackground() {
        let bg = SKSpriteNode(imageNamed: "Backgrounds")
        bg.anchorPoint = CGPoint(x: 0, y: 0)
        bg.size = size
        bg.zPosition = -10
        addChild(bg)

        let ground = SKSpriteNode(imageNamed: "Ground")
        ground.anchorPoint = CGPoint(x: 0, y: 0)
        ground.size = CGSize(width: size.width, height: size.height * 0.2)
        ground.zPosition = 2
        addChild(ground)
    }
}
