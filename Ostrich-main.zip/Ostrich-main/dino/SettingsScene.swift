import SpriteKit

class SettingsScene: SKScene {
    var previousGameScene: GameScene?

    var soundButton = SKShapeNode()
    var musicButton = SKShapeNode()
    var vibrationButton = SKShapeNode()
    var resetButton = SKShapeNode()

    override func didMove(to view: SKView) {
        removeAllChildren()
        addMenuBackground()

        let title = makeTitle("SETTINGS", fontSize: 36, x: size.width / 2, y: size.height * 0.82)
        addChild(title)

        soundButton = makeButton(text: "", name: "btnSound", width: 200)
        musicButton = makeButton(text: "", name: "btnMusic", width: 200)
        vibrationButton = makeButton(text: "", name: "btnVibration", width: 200)
        resetButton = makeButton(text: "RESET BEST SCORE", name: "btnReset", width: 200)
        let backButton = makeButton(text: "BACK", name: "btnBack", width: 200)

        soundButton.position = CGPoint(x: size.width / 2 - 110, y: size.height * 0.62)
        musicButton.position = CGPoint(x: size.width / 2 + 110, y: size.height * 0.62)
        vibrationButton.position = CGPoint(x: size.width / 2 - 110, y: size.height * 0.46)
        resetButton.position = CGPoint(x: size.width / 2 + 110, y: size.height * 0.46)
        backButton.position = CGPoint(x: size.width / 2, y: size.height * 0.29)

        addChild(soundButton)
        addChild(musicButton)
        addChild(vibrationButton)
        addChild(resetButton)
        addChild(backButton)

        updateButtons()
    }

    func onOff(_ value: Bool) -> String {
        if value {
            return "ON"
        }
        return "OFF"
    }

    func updateButtons() {
        setButtonText(soundButton, "SOUND: " + onOff(Settings.soundOn))
        setButtonText(musicButton, "MUSIC: " + onOff(Settings.musicOn))
        setButtonText(vibrationButton, "VIBRATION: " + onOff(Settings.vibrationOn))
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let button = tappedButton(self, touches)

        if button == "btnSound" {
            Settings.soundOn = !Settings.soundOn
            updateButtons()
            playSound("click.wav")
        } else if button == "btnMusic" {
            Settings.musicOn = !Settings.musicOn
            updateButtons()
            playSound("click.wav")

            if let game = previousGameScene {
                if Settings.musicOn && !game.isPausedGame {
                    game.music?.play()
                } else {
                    game.music?.pause()
                }
            }
        } else if button == "btnVibration" {
            Settings.vibrationOn = !Settings.vibrationOn
            updateButtons()
            vibrate()
            playSound("click.wav")
        } else if button == "btnReset" {
            UserDefaults.standard.set(0, forKey: "best")
            setButtonText(resetButton, "DONE!")
            playSound("click.wav")
            let wait = SKAction.wait(forDuration: 1)
            let change = SKAction.run {
                setButtonText(self.resetButton, "RESET BEST SCORE")
            }
            run(SKAction.sequence([wait, change]))
        } else if button == "btnBack" {
            playSound("click.wav")

            if let game = previousGameScene {
                game.resumeGame()
                view?.presentScene(game)
            } else {
                showScene(MenuScene(size: size), from: self)
            }
        }
    }
}
