import SpriteKit
import UIKit
import AVFoundation

class Obstacle: SKSpriteNode {
    var kind = "static"
    var passed = false
    var age: CGFloat = 0
    var isFallingIntoPit = false
}

class Pit: SKNode {
    var width: CGFloat = 100
    var triggered = false
    var passed = false
}

class CollectibleEgg: SKSpriteNode {
    var value = 1
    var isGolden = false
    var normalY: CGFloat = 0
}

class GameScene: SKScene {
    var sceneInitialized = false

    var player = SKSpriteNode()
    var bg1 = SKSpriteNode(imageNamed: "Backgrounds")
    var bg2 = SKSpriteNode(imageNamed: "Backgrounds")
    var ground1 = SKSpriteNode(imageNamed: "Ground")
    var ground2 = SKSpriteNode(imageNamed: "Ground")
    var groundCrop = SKCropNode()
    var groundMask = SKNode()
    var tint = SKSpriteNode()

    var scoreLabel = SKLabelNode(fontNamed: "AvenirNext-Bold")
    var bestLabel = SKLabelNode(fontNamed: "AvenirNext-Bold")
    var livesLabel = SKLabelNode(fontNamed: "AvenirNext-Bold")
    var shieldLabel = SKLabelNode(fontNamed: "AvenirNext-Bold")
    var levelLabel = SKLabelNode(fontNamed: "AvenirNext-Bold")
    var messageLabel = SKLabelNode(fontNamed: "AvenirNext-Bold")
    var bannerLabel = SKLabelNode(fontNamed: "AvenirNext-Bold")
    var pauseButton = SKLabelNode(fontNamed: "AvenirNext-Bold")
    var overlay = SKNode()

    var obstacles: [Obstacle] = []
    var shields: [SKLabelNode] = []
    
    var pits: [Pit] = []
    var pitTimer: TimeInterval = 10
    var isFallingIntoPit = false
    
    var eggs: [CollectibleEgg] = []
    var eggsCollected = 0
    var eggTimer: TimeInterval = 5.5

    var eggsLabel = SKLabelNode(fontNamed: "AvenirNext-Bold")

    var runFrames: [SKTexture] = []
    var falconFrames: [SKTexture] = []
    var jumpTexture = SKTexture()
    var music: AVAudioPlayer?
    var jumpSound: AVAudioPlayer?
    
    var score = 0
    var lives = 3
    var level = 1
    var hasShield = false
    var isGameOver = false
    var isPausedGame = false
    var best = UserDefaults.standard.integer(forKey: "best")

    var velocityY: CGFloat = 0
    var isOnGround = true
    var gameSpeed: CGFloat = 300

    var lastTime: TimeInterval = 0
    var hitUntil: TimeInterval = 0
    var obstacleTimer: TimeInterval = 1.5
    var shieldTimer: TimeInterval = 8

    var groundY: CGFloat = 0
    var falconFacesRight = true

    override func didMove(to view: SKView) {

        if sceneInitialized {
            lastTime = 0
            return
        }

        sceneInitialized = true
        removeAllChildren()
        groundY = size.height * 0.2
        falconFrames = autoFrames(name: "FalconAnim")

        setupBackground()
        setupGround()
        setupPlayer()
        setupLabels()
        
        if let url = Bundle.main.url(forResource: "jump", withExtension: "wav") {
            jumpSound = try? AVAudioPlayer(contentsOf: url)
            jumpSound?.volume = 0.1
            jumpSound?.prepareToPlay()
        }
        
        overlay.zPosition = 28
        addChild(overlay)
        
        print("Music enabled:", Settings.musicOn)

        if let url = Bundle.main.url(forResource: "music", withExtension: "mp3") {
            do {
                try AVAudioSession.sharedInstance().setCategory(.playback)
                try AVAudioSession.sharedInstance().setActive(true)

                // Создаём музыку независимо от настройки
                music = try AVAudioPlayer(contentsOf: url)
                music?.numberOfLoops = -1
                music?.volume = 0.5
                music?.prepareToPlay()

                // Запускаем только если музыка включена
                if Settings.musicOn {
                    music?.play()
                }

                print("Music started:", music?.isPlaying ?? false)

            } catch {
                print("Music error:", error)
            }
        } else {
            print("music.mp3 not found in app bundle")
        }
    }

    func setupBackground() {
        bg1.anchorPoint = CGPoint(x: 0, y: 0)
        bg2.anchorPoint = CGPoint(x: 0, y: 0)
        bg1.size = CGSize(width: size.width + 2, height: size.height)
        bg2.size = CGSize(width: size.width + 2, height: size.height)
        bg1.position = CGPoint(x: 0, y: 0)
        bg2.position = CGPoint(x: size.width, y: 0)
        bg1.zPosition = -10
        bg2.zPosition = -10
        addChild(bg1)
        addChild(bg2)

        tint = SKSpriteNode(color: .clear, size: size)
        tint.anchorPoint = CGPoint(x: 0, y: 0)
        tint.position = CGPoint(x: 0, y: 0)
        tint.alpha = 0
        tint.zPosition = -5
        addChild(tint)
    }

    func setupGround() {
        ground1.anchorPoint = CGPoint(x: 0, y: 0)
        ground2.anchorPoint = CGPoint(x: 0, y: 0)

        ground1.size = CGSize(width: size.width + 2, height: groundY)
        ground2.size = CGSize(width: size.width + 2, height: groundY)

        ground1.position = CGPoint(x: 0, y: 0)
        ground2.position = CGPoint(x: size.width, y: 0)

        ground1.zPosition = 0
        ground2.zPosition = 0

        groundCrop.zPosition = 2
        addChild(groundCrop)

        groundCrop.addChild(ground1)
        groundCrop.addChild(ground2)

        groundCrop.maskNode = groundMask

        updateGroundMask()
    }
    
    func updateGroundMask() {
        groundMask.removeAllChildren()

        let sortedPits = pits.sorted {
            $0.position.x < $1.position.x
        }

        var currentX: CGFloat = 0

        for pit in sortedPits {
            let left = max(0, min(size.width, pit.position.x - pit.width / 2))
            let right = max(0, min(size.width, pit.position.x + pit.width / 2))

            if left > currentX {
                let segment = SKSpriteNode(
                    color: .white,
                    size: CGSize(
                        width: left - currentX,
                        height: groundY
                    )
                )

                segment.anchorPoint = CGPoint(x: 0, y: 0)
                segment.position = CGPoint(x: currentX, y: 0)

                groundMask.addChild(segment)
            }

            currentX = max(currentX, right)
        }

        if currentX < size.width {
            let segment = SKSpriteNode(
                color: .white,
                size: CGSize(
                    width: size.width - currentX,
                    height: groundY
                )
            )

            segment.anchorPoint = CGPoint(x: 0, y: 0)
            segment.position = CGPoint(x: currentX, y: 0)

            groundMask.addChild(segment)
        }
    }

    func setupPlayer() {
        runFrames = cutFrames(name: "OstrichRun", count: 4)
        jumpTexture = cutFrames(name: "OstrichJump", count: 2)[0]

        player.texture = runFrames[0]
        player.size = CGSize(width: 80, height: 80)
        player.anchorPoint = CGPoint(x: 0.5, y: 0)
        player.position = CGPoint(x: size.width * 0.2, y: groundY)
        player.zPosition = 5
        addChild(player)

        runAnimation()
    }

    func runAnimation() {
        let animation = SKAction.animate(with: runFrames, timePerFrame: 0.09)
        player.run(SKAction.repeatForever(animation), withKey: "run")
    }

    func makeLabel(_ label: SKLabelNode, fontSize: CGFloat, x: CGFloat, y: CGFloat, align: SKLabelHorizontalAlignmentMode) {
        label.fontSize = fontSize
        label.fontColor = .white
        label.horizontalAlignmentMode = align
        label.position = CGPoint(x: x, y: y)
        label.zPosition = 20
        addChild(label)
    }

    func setupLabels() {
        let insets = view?.safeAreaInsets ?? UIEdgeInsets.zero
        let leftX = insets.left + 24
        let rightX = size.width - insets.right - 24
        let topY = size.height - insets.top - 40

        makeLabel(scoreLabel, fontSize: 20, x: rightX, y: topY, align: .right)
        makeLabel(bestLabel, fontSize: 15, x: rightX, y: topY - 26, align: .right)
        makeLabel(eggsLabel, fontSize: 16, x: rightX, y: topY - 50, align: .right)
        makeLabel(livesLabel, fontSize: 22, x: leftX, y: topY, align: .left)
        makeLabel(shieldLabel, fontSize: 15, x: leftX, y: topY - 26, align: .left)
        makeLabel(pauseButton, fontSize: 30, x: size.width / 2, y: topY, align: .center)
        makeLabel(levelLabel, fontSize: 15, x: size.width / 2, y: topY - 26, align: .center)
        makeLabel(messageLabel, fontSize: 27, x: size.width / 2, y: size.height * 0.62, align: .center)
        makeLabel(bannerLabel, fontSize: 30, x: size.width / 2, y: size.height * 0.72, align: .center)

        pauseButton.text = "II"

        messageLabel.numberOfLines = 0
        messageLabel.verticalAlignmentMode = .center
        messageLabel.zPosition = 30

        bannerLabel.numberOfLines = 0
        bannerLabel.verticalAlignmentMode = .center
        bannerLabel.fontColor = .yellow
        bannerLabel.alpha = 0

        updateLabels()
    }

    func updateLabels() {
        scoreLabel.text = "SCORE: \(score)"
        bestLabel.text = "BEST: \(best)"
        eggsLabel.text = "🥚: \(eggsCollected)"
        livesLabel.text = String(repeating: "❤️", count: lives)
        levelLabel.text = "LEVEL \(level)"
        if hasShield {
            shieldLabel.text = "🛡 SHIELD ACTIVE"
        } else {
            shieldLabel.text = ""
        }
    }

    func showOverlay(text: String, buttons: [(String, String)]) {
        overlay.removeAllChildren()

        let dim = SKSpriteNode(color: SKColor(white: 0, alpha: 0.55), size: size)
        dim.anchorPoint = CGPoint(x: 0, y: 0)
        dim.position = CGPoint(x: 0, y: 0)
        overlay.addChild(dim)

        messageLabel.text = text

        let count = CGFloat(buttons.count)
        let startX = size.width / 2 - (count - 1) * 90
        for (i, item) in buttons.enumerated() {
            let button = makeButton(text: item.0, name: item.1, width: 165)
            button.position = CGPoint(x: startX + CGFloat(i) * 180, y: size.height * 0.3)
            overlay.addChild(button)
        }
    }

    func hideOverlay() {
        overlay.removeAllChildren()
        messageLabel.text = ""
    }

    func pauseGame() {
        isPausedGame = true
        player.isPaused = true

        for obstacle in obstacles {
            obstacle.isPaused = true
        }

        music?.pause()

        showOverlay(
            text: "PAUSED",
            buttons: [
                ("RESTART", "btnRestart"),
                ("MENU", "btnMenu"),
                ("SETTINGS", "btnSettings")
            ]
        )
    }

    func resumeGame() {
        isPausedGame = false
        player.isPaused = false

        for obstacle in obstacles {
            obstacle.isPaused = false
        }

        if Settings.musicOn {
            music?.play()
        } else {
            music?.pause()
        }

        hideOverlay()
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let location = touches.first!.location(in: self)
        let button = tappedButton(self, touches)

        if isGameOver || isPausedGame {

            if button == "btnRestart" {
                playSound("click.wav")
                music?.stop()
                showScene(GameScene(size: size), from: self)

            } else if button == "btnMenu" {
                playSound("click.wav")
                music?.stop()
                showScene(MenuScene(size: size), from: self)

            } else if button == "btnSettings" && isPausedGame {
                playSound("click.wav")

                let settings = SettingsScene(size: size)
                settings.scaleMode = scaleMode
                settings.previousGameScene = self

                music?.pause()
                view?.presentScene(settings)

            } else if isPausedGame {
                resumeGame()
            }

            return
        }

        if pauseButton.frame.insetBy(dx: -30, dy: -30).contains(location) {
            pauseGame()
            return
        }

        if isOnGround {
            isOnGround = false
            velocityY = 850

            gameVibrate(.light)

            if Settings.soundOn {
                jumpSound?.currentTime = 0
                jumpSound?.play()
            }

            player.removeAction(forKey: "run")
            player.texture = jumpTexture
        }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if isPausedGame || isGameOver {
            return
        }

        if !isOnGround && velocityY > 400 {
            velocityY = 400
        }
    }

    override func update(_ currentTime: TimeInterval) {
        var dt = currentTime - lastTime
        lastTime = currentTime
        if dt > 0.05 {
            dt = 0.05
        }

        if isGameOver || isPausedGame || isFallingIntoPit {
            return
        }

        let d = CGFloat(dt)

        let targetSpeed = min(560, 300 + CGFloat(level - 1) * 35)
        if gameSpeed < targetSpeed {
            gameSpeed += 50 * d
        }

        moveBackground(d)
        moveObjects(d)

        // Сначала обновляем положение страуса
        movePlayer(d)

        // Проверяем, не начал ли страус падать
        checkPitFall()

        if isGameOver || isFallingIntoPit {
            return
        }

        // Теперь двигаем ямы и начисляем очки
        movePits(d)
        checkPitFall()

        if isGameOver || isFallingIntoPit {
            return
        }

        // Проверяем, не попали ли камни в яму
        checkRocksFallingIntoPits()

        moveEggs(d)
        spawnThings(dt)
        checkHits(currentTime)
        collectEggs()

        if currentTime < hitUntil {
            player.alpha = 0.4
        } else {
            player.alpha = 1
        }
    }

    func movePlayer(_ d: CGFloat) {
        if isOnGround {
            return
        }

        if velocityY < 0 {
            velocityY -= 2900 * d
        } else {
            velocityY -= 2300 * d
        }
        player.position.y += velocityY * d

        if player.position.y <= groundY {
            if isOverPit() {
                startPitFall()
                return
            }

            player.position.y = groundY
            velocityY = 0
            isOnGround = true
            runAnimation()
        }
    }

    func moveBackground(_ d: CGFloat) {
        ground1.position.x -= gameSpeed * d
        ground2.position.x -= gameSpeed * d
        bg1.position.x -= gameSpeed * 0.25 * d
        bg2.position.x -= gameSpeed * 0.25 * d

        if ground1.position.x <= -size.width {
            ground1.position.x += size.width * 2
        }
        if ground2.position.x <= -size.width {
            ground2.position.x += size.width * 2
        }
        if bg1.position.x <= -size.width {
            bg1.position.x += size.width * 2
        }
        if bg2.position.x <= -size.width {
            bg2.position.x += size.width * 2
        }
    }

    func checkRocksFallingIntoPits() {
        for obstacle in obstacles {

            // Только наземные препятствия
            guard !obstacle.kind.hasPrefix("falcon"),
                  !obstacle.isFallingIntoPit,
                  obstacle.parent != nil else {
                continue
            }

            for pit in pits {
                let pitLeft = pit.position.x - pit.width / 2
                let pitRight = pit.position.x + pit.width / 2

                // Камень движется справа налево.
                // Проверяем, оказался ли его центр над ямой.
                if obstacle.position.x > pitLeft &&
                   obstacle.position.x < pitRight {

                    obstacle.isFallingIntoPit = true

                    // Убираем камень из столкновений и начисления очков
                    obstacle.removeFromParent()

                    // Создаём визуальную копию для анимации падения
                    let fallingRock = SKSpriteNode(texture: obstacle.texture)
                    fallingRock.size = obstacle.size
                    fallingRock.position = obstacle.position
                    fallingRock.anchorPoint = obstacle.anchorPoint
                    fallingRock.color = obstacle.color
                    fallingRock.colorBlendFactor = obstacle.colorBlendFactor
                    fallingRock.zPosition = 1

                    addChild(fallingRock)

                    let fall = SKAction.group([
                        SKAction.moveBy(
                            x: -25,
                            y: -groundY - 60,
                            duration: 0.35
                        ),
                        SKAction.rotate(
                            byAngle: -.pi / 3,
                            duration: 0.35
                        ),
                        SKAction.fadeOut(
                            withDuration: 0.35
                        )
                    ])

                    fallingRock.run(
                        SKAction.sequence([
                            fall,
                            SKAction.removeFromParent()
                        ])
                    )

                    break
                }
            }
        }

        obstacles.removeAll { $0.parent == nil }
    }
    
    func moveObjects(_ d: CGFloat) {
        for obstacle in obstacles {
            var speed = gameSpeed
            if obstacle.kind == "fast" {
                speed = gameSpeed * 1.5
            } else if obstacle.kind.hasPrefix("falcon") {
                speed = gameSpeed * 1.2
            }

            obstacle.position.x -= speed * d
            obstacle.age += d

            if obstacle.kind == "hopper" {
                obstacle.position.y = groundY - 4 + abs(sin(obstacle.age * 4)) * 85
            } else if obstacle.kind == "falconWave" {
                obstacle.position.y = groundY + 70 + sin(obstacle.age * 3.5) * 55
            }

            if !obstacle.passed && obstacle.position.x < player.position.x - 20 {
                obstacle.passed = true
                score += 1
                playSound("point.wav")
                checkLevel()
                updateLabels()
            }

            if obstacle.position.x < -80 {
                obstacle.removeFromParent()
            }
        }
        obstacles.removeAll { $0.parent == nil }

        for shield in shields {
            shield.position.x -= gameSpeed * d
            if shield.position.x < -80 {
                shield.removeFromParent()
            }
        }
        shields.removeAll { $0.parent == nil }
    }

    func checkLevel() {
        let newLevel = score / 8 + 1
        if newLevel > level {
            level = newLevel
            levelUp()
        }
    }

    func levelUp() {
        playSound("levelup.wav")

        var text = "LEVEL \(level)"
        if level == 2 {
            text += "\nFast rocks"
        } else if level == 3 {
            text += "\nFalcons!"
        } else if level == 4 {
            text += "\nHopping rocks"
        } else if level == 5 {
            text += "\nWavy falcons!"
        }

        bannerLabel.text = text
        bannerLabel.removeAllActions()
        bannerLabel.alpha = 1
        bannerLabel.run(SKAction.sequence([SKAction.wait(forDuration: 1.8), SKAction.fadeOut(withDuration: 0.4)]))

        let colors = [SKColor.orange, SKColor.purple, SKColor.red, SKColor.blue, SKColor.black]
        tint.color = colors[(level - 2) % colors.count]
        tint.alpha = 0
        tint.run(SKAction.fadeAlpha(to: 0.25, duration: 1))
    }

    func spawnThings(_ dt: TimeInterval) {
        obstacleTimer -= dt
        if obstacleTimer <= 0 {
            let spawnX = size.width + 50

            let eggNearby = eggs.contains { egg in
                abs(egg.position.x - spawnX) < 135
            }

            let pitNearby = pits.contains { pit in
                abs(pit.position.x - spawnX) < pit.width / 2 + 180
            }

            if !eggNearby && !pitNearby {
                spawnObstacle()
            }
            let minGap = max(0.9, 1.5 - Double(level - 1) * 0.1)
            obstacleTimer = Double.random(in: minGap...(minGap + 1.0))
        }

        shieldTimer -= dt
        if shieldTimer <= 0 {
            spawnShield()
            shieldTimer = Double.random(in: 9...14)
        }
        
        eggTimer -= dt

        if eggTimer <= 0 {
            if Int.random(in: 1...100) <= 80 {
                spawnEgg()
            }

            if eggTimer <= 0 {
                eggTimer = Double.random(in: 5...8)
            }
        }
        // Ямы появляются начиная с LEVEL 3
        if level >= 3 {
            pitTimer -= dt

            if pitTimer <= 0 {
                if canSpawnPit() {
                    spawnPit()
                    pitTimer = Double.random(in: 12...17)
                } else {
                    pitTimer = 1.0
                }
            }
        }
    }

    func chooseKind() -> String {
        var kinds = ["static", "static"]
        if level >= 2 {
            kinds.append("fast")
        }
        if level >= 3 {
            kinds.append("falconLow")
            kinds.append("falconHigh")
        }
        if level >= 4 {
            kinds.append("hopper")
        }
        if level >= 5 {
            kinds.append("falconWave")
        }
        return kinds.randomElement()!
    }

    func spawnObstacle() {
        let kind = chooseKind()
        let obstacle: Obstacle

        if kind.hasPrefix("falcon") {
            obstacle = Obstacle(texture: falconFrames[0])
            let frameSize = falconFrames[0].size()
            let height: CGFloat = 44
            var width: CGFloat = 60
            if frameSize.height > 0 {
                width = height * frameSize.width / frameSize.height
            }
            obstacle.size = CGSize(width: width, height: height)
            obstacle.anchorPoint = CGPoint(x: 0.5, y: 0.5)
            if falconFacesRight {
                obstacle.xScale = -1
            }

            if kind == "falconLow" {
                obstacle.position = CGPoint(x: size.width + 50, y: groundY + 35)
            } else if kind == "falconHigh" {
                obstacle.position = CGPoint(x: size.width + 50, y: groundY + 62)
            } else {
                obstacle.position = CGPoint(x: size.width + 50, y: groundY + 70)
            }

            if falconFrames.count > 1 {
                let animation = SKAction.animate(with: falconFrames, timePerFrame: 0.1)
                obstacle.run(SKAction.repeatForever(animation))
            }
        } else {
            var name = ["Rock1", "Rock2", "Rock3", "Tree1", "Tree2"].randomElement()!
            if kind == "fast" || kind == "hopper" {
                name = ["Rock1", "Rock2", "Rock3"].randomElement()!
            }

            obstacle = Obstacle(imageNamed: name)
            obstacle.size = CGSize(width: 46, height: 46)
            obstacle.anchorPoint = CGPoint(x: 0.5, y: 0)
            obstacle.position = CGPoint(x: size.width + 50, y: groundY - 4)

            if kind == "fast" {
                obstacle.color = .red
                obstacle.colorBlendFactor = 0.45
            } else if kind == "hopper" {
                obstacle.color = .blue
                obstacle.colorBlendFactor = 0.45
            }
        }

        obstacle.kind = kind
        obstacle.zPosition = 4
        addChild(obstacle)
        obstacles.append(obstacle)
    }
    
    func eggWillBeOverPit(spawnX: CGFloat) -> Bool {
        let eggTravelTime = (spawnX - player.position.x) / max(gameSpeed, 1)

        for pit in pits {
            let predictedPitX = pit.position.x - gameSpeed * eggTravelTime

            if abs(predictedPitX - player.position.x) < pit.width / 2 + 35 {
                return true
            }
        }

        return false
    }

    func spawnEgg() {
        let isGolden = Int.random(in: 1...100) <= 19

        let egg = CollectibleEgg(
            imageNamed: isGolden ? "egggold" : "egg"
        )

        egg.isGolden = isGolden
        egg.value = isGolden ? 5 : 1

        egg.size = CGSize(width: 40, height: 42)
        egg.zPosition = 7

        let spawnX = size.width + 65

        let abovePit = eggWillBeOverPit(spawnX: spawnX)

        let possibleHeights: [CGFloat] = abovePit
            ? [groundY + 100]
            : [groundY + 27, groundY + 100]

        let eggTravelTime = (spawnX - player.position.x) / max(gameSpeed, 1)

        let safeToSpawn = obstacles.allSatisfy { obstacle in
            let obstacleSpeed: CGFloat

            if obstacle.kind == "fast" {
                obstacleSpeed = gameSpeed * 1.5
            } else if obstacle.kind.hasPrefix("falcon") {
                obstacleSpeed = gameSpeed * 1.2
            } else {
                obstacleSpeed = gameSpeed
            }

            let predictedX = obstacle.position.x - obstacleSpeed * eggTravelTime

            return abs(predictedX - player.position.x) > 125
        }

        guard safeToSpawn else {
            eggTimer = 0.8
            return
        }

        egg.normalY = possibleHeights.randomElement()!

        egg.position = CGPoint(
            x: spawnX,
            y: egg.normalY
        )

        // Лёгкое покачивание
        let floatUp = SKAction.moveBy(x: 0, y: 5, duration: 0.6)
        floatUp.timingMode = .easeInEaseOut

        let floatDown = floatUp.reversed()

        egg.run(
            SKAction.repeatForever(
                SKAction.sequence([floatUp, floatDown])
            )
        )

        if isGolden {
            // Мягкое свечение золотого яйца
            let glow = SKEffectNode()
            glow.shouldRasterize = true

            let glowSprite = SKSpriteNode(
                imageNamed: "egggold"
            )

            glowSprite.size = egg.size
            glowSprite.alpha = 0.45

            glow.filter = CIFilter(
                name: "CIGaussianBlur",
                parameters: [kCIInputRadiusKey: 7]
            )

            glow.addChild(glowSprite)
            glow.zPosition = -1

            egg.addChild(glow)
        }

        addChild(egg)
        eggs.append(egg)
    }
    
    func moveEggs(_ d: CGFloat) {
        for egg in eggs {
            egg.position.x -= gameSpeed * d
            let abovePit = pits.contains { pit in
                abs(egg.position.x - pit.position.x) < pit.width / 2 + 15
            }

            let targetY: CGFloat

            if abovePit && egg.normalY < groundY + 65 {
                targetY = groundY + 100
            } else {
                targetY = egg.normalY
            }

            if egg.normalY != targetY {
                egg.position.y += targetY - egg.normalY
                egg.normalY = targetY
            }

            if egg.position.x < -60 {
                egg.removeFromParent()
            }
        }

        eggs.removeAll { $0.parent == nil }
    }
    
    func collectEggs() {
        let playerRect = CGRect(
            x: player.position.x - 16,
            y: player.position.y + 6,
            width: 32,
            height: 54
        )

        for egg in eggs {
            let eggRect = CGRect(
                x: egg.position.x - 14,
                y: egg.position.y - 18,
                width: 28,
                height: 36
            )

            if playerRect.intersects(eggRect) {
                eggsCollected += egg.value

                playSound("egg.mp3")

                gameVibrate(.soft)

                let amount = egg.value
                let pickupPosition = egg.position

                egg.removeFromParent()

                updateLabels()

                let popup = SKLabelNode(fontNamed: "AvenirNext-Bold")
                popup.text = "+\(amount)"
                popup.fontSize = 22
                popup.fontColor = amount == 5 ? .yellow : .white
                popup.position = pickupPosition
                popup.zPosition = 25

                addChild(popup)

                popup.run(
                    SKAction.sequence([
                        SKAction.group([
                            SKAction.moveBy(
                                x: 0,
                                y: 35,
                                duration: 0.5
                            ),
                            SKAction.fadeOut(
                                withDuration: 0.5
                            )
                        ]),
                        SKAction.removeFromParent()
                    ])
                )
            }
        }

        eggs.removeAll { $0.parent == nil }
    }
    
    func canSpawnPit() -> Bool {

        let spawnX = size.width + 80

        // Не создаём яму рядом с препятствиями

        for obstacle in obstacles {
            let safeDistance: CGFloat = 260

            if abs(obstacle.position.x - spawnX) < safeDistance {
                return false
            }
        }

        // Не создаём яму рядом с низкими яйцами
        for egg in eggs {
            let isLowEgg = egg.position.y < groundY + 65

            if isLowEgg &&
               abs(egg.position.x - spawnX) < 180 {
                return false
            }
        }

        // Не создаём яму рядом со щитами

        for shield in shields {

            if abs(shield.position.x - spawnX) < 180 {

                return false

            }

        }

        return true

    }
    
    func spawnPit() {
        let pit = Pit()

        pit.width = CGFloat.random(in: 75...95)
        pit.position = CGPoint(
            x: size.width + 80,
            y: groundY
        )
        pit.zPosition = 3

        // Текстура существующей земли
        let groundTexture = SKTexture(imageNamed: "Ground")
        groundTexture.filteringMode = .nearest

        let wallHeight = groundY
        let wallWidth: CGFloat = 6

        for side in [-1, 1] {
            let direction = CGFloat(side)

            // Края пропасти
            let edgeX = direction * pit.width / 2

            // Стенка с текстурой земли
            let wall = SKSpriteNode(
                color: SKColor(
                    red: 0.43,
                    green: 0.23,
                    blue: 0.18,
                    alpha: 1
                ),
                size: CGSize(width: wallWidth, height: wallHeight)
            )

            wall.size = CGSize(
                width: wallWidth,
                height: wallHeight
            )

            wall.anchorPoint = CGPoint(x: 0.5, y: 1)

            // Располагаем стенку со стороны земли,
            // а не внутри пропасти
            wall.position = CGPoint(
                x: edgeX + direction * wallWidth / 2,
                y: 0
            )

            wall.zPosition = 1
            pit.addChild(wall)

        }

        addChild(pit)
        pits.append(pit)

        updateGroundMask()
    }
    
    func movePits(_ d: CGFloat) {
        for pit in pits {
            pit.position.x -= gameSpeed * d

            let rightEdge = pit.position.x + pit.width / 2

            // Начисляем очко только после полного преодоления ямы
            if !pit.passed &&
               rightEdge < player.position.x - 16 &&
               !isFallingIntoPit &&
               !isGameOver {

                pit.passed = true

                score += 1
                playSound("point.wav")

                checkLevel()
                updateLabels()
            }

            if pit.position.x < -pit.width {
                pit.removeFromParent()
            }
        }

        pits.removeAll { $0.parent == nil }
        updateGroundMask()
    }
    
    func isOverPit() -> Bool {
        for pit in pits {
            let leftEdge = pit.position.x - pit.width / 2
            let rightEdge = pit.position.x + pit.width / 2

            if player.position.x > leftEdge + 8 &&
               player.position.x < rightEdge - 8 {
                return true
            }
        }

        return false
    }
    func startPitFall() {
        guard !isFallingIntoPit && !isGameOver else {
            return
        }

        isFallingIntoPit = true
        isOnGround = false
        velocityY = 0

        player.removeAction(forKey: "run")

        let fall = SKAction.sequence([
            SKAction.moveTo(y: -100, duration: 0.45),
            SKAction.run { [weak self] in
                self?.gameOver()
            }
        ])

        player.run(fall, withKey: "pitFall")
    }
    
    func checkPitFall() {
        guard !isFallingIntoPit && !isGameOver else {
            return
        }

        if isOnGround && isOverPit() {
            startPitFall()
        }
    }
    
    func spawnShield() {
        let shield = SKLabelNode(text: "🛡️")
        shield.fontSize = 32
        shield.verticalAlignmentMode = .center
        shield.position = CGPoint(x: size.width + 40, y: groundY + 105)
        shield.zPosition = 8
        addChild(shield)
        shields.append(shield)
    }

    func hitRect(_ obstacle: Obstacle) -> CGRect {
        if obstacle.kind.hasPrefix("falcon") {
            return CGRect(x: obstacle.position.x - 20, y: obstacle.position.y - 9, width: 40, height: 18)
        }
        return CGRect(x: obstacle.position.x - 14, y: obstacle.position.y, width: 28, height: 32)
    }

    func checkHits(_ currentTime: TimeInterval) {
        let playerRect = CGRect(x: player.position.x - 16, y: player.position.y + 6, width: 32, height: 54)

        for shield in shields {
            let shieldRect = CGRect(x: shield.position.x - 18, y: shield.position.y - 18, width: 36, height: 36)
            if shieldRect.intersects(playerRect) {
                hasShield = true

                gameVibrate(.medium)

                playSound("shield.wav")
                shield.removeFromParent()
                updateLabels()
            }
        }
        shields.removeAll { $0.parent == nil }

        if currentTime < hitUntil {
            return
        }

        for obstacle in obstacles {
            if hitRect(obstacle).intersects(playerRect) {
                obstacle.removeFromParent()
                playSound("hit.wav")
                gameVibrate(.heavy)

                if hasShield {
                    hasShield = false
                } else {
                    lives -= 1
                    hitUntil = currentTime + 1.2
                }

                updateLabels()

                if lives <= 0 {
                    gameOver()
                }
                break
            }
        }
        obstacles.removeAll { $0.parent == nil }
    }

    func gameOver() {
        isGameOver = true
        player.removeAllActions()
        player.alpha = 1
        music?.stop()
        playSound("gameover.wav")

        var text = "GAME OVER\nScore: \(score)   Level: \(level)\n🥚: \(eggsCollected)"
        if score > best {
            best = score
            UserDefaults.standard.set(best, forKey: "best")
            text += "\nNEW BEST!"
        }
        updateLabels()
        showOverlay(text: text, buttons: [("PLAY AGAIN", "btnRestart"), ("MENU", "btnMenu")])
    }
}
