import SpriteKit

class MenuScene: SKScene {

    override func didMove(to view: SKView) {
        removeAllChildren()
        addMenuBackground()

        let title = makeTitle("OSTRICH ADVENTURE", fontSize: 40, x: size.width / 2, y: size.height * 0.78)
        addChild(title)

        let best = UserDefaults.standard.integer(forKey: "best")
        let bestLabel = makeTitle("BEST SCORE: \(best)", fontSize: 20, x: size.width / 2, y: size.height * 0.68)
        addChild(bestLabel)

        let playButton = makeButton(text: "PLAY", name: "btnPlay", width: 220)
        playButton.position = CGPoint(x: size.width / 2, y: size.height * 0.5)
        addChild(playButton)

        let settingsButton = makeButton(text: "SETTINGS", name: "btnSettings", width: 220)
        settingsButton.position = CGPoint(x: size.width / 2, y: size.height * 0.34)
        addChild(settingsButton)

        let frames = cutFrames(name: "OstrichRun", count: 4)
        let ostrich = SKSpriteNode(texture: frames[0])
        ostrich.size = CGSize(width: 80, height: 80)
        ostrich.anchorPoint = CGPoint(x: 0.5, y: 0)
        ostrich.position = CGPoint(x: size.width * 0.82, y: size.height * 0.2)
        ostrich.zPosition = 5
        ostrich.run(SKAction.repeatForever(SKAction.animate(with: frames, timePerFrame: 0.09)))
        addChild(ostrich)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let button = tappedButton(self, touches)

        if button == "btnPlay" {
            playSound("click.wav")
            showScene(GameScene(size: size), from: self)
        } else if button == "btnSettings" {
            playSound("click.wav")
            showScene(SettingsScene(size: size), from: self)
        }
    }
}
